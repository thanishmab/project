Restaurant Management system By Thanishma

This is the miniproject for C361 Wiley Edge.It is a Restaurant Management Web Application made using flask.

Features:
Menu Optimization
Table Management 
Easy UI Interface

Demonstration
![image](https://github.com/thanishma/project1/assets/73327713/521826f9-e037-44ba-ab22-c7dc5362851c)

![image](https://github.com/thanishma/project1/assets/73327713/6ce3318c-ea02-44dc-89cb-515636141273)

![image](https://github.com/thanishma/project1/assets/73327713/6956a68d-3473-4893-a512-1fba6dac2830)

![image](https://github.com/thanishma/project1/assets/73327713/18630867-4b8a-4133-bc26-7c0e03f067f1)

![image](https://github.com/thanishma/project1/assets/73327713/fd6e6771-4eaa-43f2-a5c9-b0b990b2c953)

![image](https://github.com/thanishma/project1/assets/73327713/ad48eedb-f561-4e35-8d3a-8a25739fd2f3)

![image](https://github.com/thanishma/project1/assets/73327713/18630867-4b8a-4133-bc26-7c0e03f067f1)
